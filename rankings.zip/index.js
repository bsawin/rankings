// Import the required AWS SDK for JavaScript.
const AWS = require('aws-sdk');
// Import the Cheerio library.
const cheerio = require('cheerio');

exports.handler = async (event) => {
    // Example HTML string to parse with Cheerio.
    const html = '<!DOCTYPE html><html><head><title>Page Title</title></head><body><h1>This is a Heading</h1><p>This is a paragraph.</p></body></html>';

    // Load the HTML string with Cheerio.
    const $ = cheerio.load(html);

    // Extract the text of the heading using Cheerio.
    const headingText = $('h1').text();

    // Return the extracted text.
    return {
        statusCode: 200,
        body: JSON.stringify({
            heading: headingText
        }),
    };
};
